-- phpMyAdmin SQL Dump
-- version 4.5.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 04-Jun-2017 às 19:41
-- Versão do servidor: 5.7.11
-- PHP Version: 5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `prova`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_atividades`
--

CREATE TABLE `tb_atividades` (
  `ID` int(11) NOT NULL,
  `NOME` varchar(255) NOT NULL,
  `DESCRICAO` text NOT NULL,
  `DATA_INICIO` date NOT NULL,
  `DATA_FIM` date DEFAULT NULL,
  `STATUS` int(2) NOT NULL,
  `SITUACAO` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `tb_atividades`
--

INSERT INTO `tb_atividades` (`ID`, `NOME`, `DESCRICAO`, `DATA_INICIO`, `DATA_FIM`, `STATUS`, `SITUACAO`) VALUES
(8, 'JEFERSON SANTAna', 'na Região Metropolitana de Goiânia, disse, neste domingo (4), que a enteada está em choque e teme uma nova explosão. Taynna Karita Silva Barros, de 20 anos, morava em uma casa alugada ao lado da unij kljlkasd\r\nkasdkljlkasd \r\n', '2017-01-17', '2017-05-10', 2, 'Ativo'),
(9, 'santana', 'Esta atividade deve ser feita até o dia 06/08/2017 loga após a atividade de número 2.\r\nNão pode haver atraso nesta atividade para que não prejudique o andamento das demais atividades.\r\n\r\nCaso necessário alinhar com o líder imediato para que sejam tomadas ações necessárias.', '2017-06-04', '2017-08-06', 1, 'Ativo'),
(10, 'MARIA ', 'OOOOO', '2017-06-04', '2017-06-04', 4, 'Inativo'),
(11, 'CARLOS ALBERTO SILVA', 'TESTANDO 123', '2017-06-04', NULL, 3, 'Inativo');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_status`
--

CREATE TABLE `tb_status` (
  `ID` int(2) NOT NULL,
  `NOME` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `tb_status`
--

INSERT INTO `tb_status` (`ID`, `NOME`) VALUES
(4, 'Concluído'),
(2, 'Em Desenvolvimento'),
(3, 'Em Teste'),
(1, 'Pendente');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_atividades`
--
ALTER TABLE `tb_atividades`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `fk_status` (`STATUS`);

--
-- Indexes for table `tb_status`
--
ALTER TABLE `tb_status`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `UN_NOME_STATUS` (`NOME`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_atividades`
--
ALTER TABLE `tb_atividades`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `tb_atividades`
--
ALTER TABLE `tb_atividades`
  ADD CONSTRAINT `fk_status` FOREIGN KEY (`STATUS`) REFERENCES `tb_status` (`ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
