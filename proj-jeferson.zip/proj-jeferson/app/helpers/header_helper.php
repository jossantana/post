<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>
	
	<script src="http://<?=base_url()?>assets/jquery/jquery-3.2.1.min.js"></script>
	
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" type="text/css" href="http://<?=base_url()?>assets/bootstrap-3.3.7/dist/css/bootstrap.min.css"/>

	<!-- Latest compiled and minified JavaScript -->
	<script src="http://<?=base_url()?>assets/bootstrap-3.3.7/dist/js/bootstrap.min.js"></script>
</head>
<body>