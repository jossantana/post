<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">WebSite - Jeferson Santana</a>
    </div>
    <ul class="nav navbar-nav">
     
      <li><a href="http://<?=base_url()?>atividade">Atividades</a></li>
    </ul>
  </div>
</nav>