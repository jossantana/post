<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Atividade extends CI_Controller {
	public $nome, $descricao, $datafim, $datainicio, $status, $id, $situacao;
	
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 
	public function __construct(){
        parent::__construct();
      
		
    }
	public function index()
	{
		$this->load->model("atividades");
		$dados = $this->atividades->allAtivt();
		$dadosStatus = $this->atividades->allStatus();
		$data['allStatusAtividades'] = $dadosStatus;
		$data['allAtividades'] = $dados;		
		$data['mostraAtividade'] = '';
		$this->load->view('atividade', $data);
	}
	public function editaSalvar(){
		
		$array = array('nome' => $this->input->post('nome'),'descricao'=>$this->input->post('descricao'),
					   'datainicio' => $this->input->post('dtinicio'), 'datafim' => $this->input->post('dtfim'),
					   'situacao' => $this->input->post('situacao'), 'status' => $this->input->post('status'),
					   'id' => $this->input->post('idAtividade'));
		$this->load->model("atividades");
		
		if($this->input->post('acao') === 'edit'){
			if($this->atividades->atualizar($array)){
				echo  'Sucesso Atualização';
			}
		}else{
			if($this->atividades->salvar($array)){
				echo  'Sucesso Inclusão';
			}
		}
		
		
		
	}
}
