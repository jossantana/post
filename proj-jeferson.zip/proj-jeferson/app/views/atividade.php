<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->helper('header');
?>
<style>
.row{
    margin-top:40px;
    padding: 0 10px;
}
.clickable{
    cursor: pointer;   
}

.panel-heading div {
	margin-top: -18px;
	font-size: 15px;
}
.panel-heading div span{
	margin-left:5px;
}
.panel-body{
	display: none;
	width:100%;
}
.col-md-6{
	width:100%;
}
.panel-body{
	width:50%;
}
.col-xs-5 {
    width: 60.66666667%;
}
</style>
<link rel="stylesheet" type="text/css" href="http://<?=base_url()?>assets/bootstrap-3.3.7/dist/css/calendario.css"/>
<div class="container">
	<h1>Lista de Atividades</h1>
	
		<?php $this->load->helper('menu'); ?>

		<?php 
			$sel='';			
			foreach($allStatusAtividades as $val){
				$sel .= '<option value="'.$val->ID.'">'.$val->NOME.'</option>';
				
			}
			$fundo = null;
			$botao = null;
			
			$x=0;
			foreach($allAtividades as $l){
				$datafim = null;
				if($l->IDSTATUS == 4){
					$fundo = 'style="background-color:#0B486B; color:#fff;"';
					$botao = null;
				}else{
					$fundo = null;
					$botao = '<button class="btn btn-default" data-toggle="modal" id="bts" onclick="javascript:capturadados('.$l->ID.');" data-target="#loginModal" value="'.$l->ID.'">
											Editar
											</button>';
				}
				if($l->DATA_FIM){
					$datafim = date('d-m-Y', strtotime($l->DATA_FIM));
				}
				$mostraAtividade .= '<tr '.$fundo.'>
										<td>'.$l->ID.'</td>
										<td class="n'.$l->ID.'">'.$l->NOME.'</td>
										<td style="width:25%;" class="d'.$l->ID.'">'.$l->DESCRICAO.'</td>
										<td class="dti'.$l->ID.'">'.date('d-m-Y', strtotime($l->DATA_INICIO)).'</td>
										<td class="dtf'.$l->ID.'">'.$datafim.'</td>
										<td class="si'.$l->ID.'">'.$l->SITUACAO.'</td>
										<td class="st'.$l->ID.'">'.$l->NOMESTATUS.'</td>
										<td>
											'.$botao.'
										</td>
									</tr>';
				$x++;				
			}
	
		?>			
    	<div class="row">		
			<div class="col-md-6">
				<div class="panel panel-success">
					<div class="panel-heading">
						<h3 class="panel-title">Atividades</h3>
						
					</div>
										
					<table class="table table-hover" id="task-table">
						<thead>
							<tr>
								<th>#</th>
								<th>NOME</th>
								<th>DESCRIÇÃO</th>
								<th>DATA INÍCIO</th>
								<th>DATA FIM</th>
								<th>SITUAÇÃO</th>
								<th>STATUS</th>
								<th>
									AÇÃO
								</th>
							</tr>
							<tr>
								<th></th>
								<th></th>
								<th></th>
								<th></th>
								<th></th>
								<th>
									<input type="text" class="form-control" style="width:120px;" id="txtColuna1"/>
								</th>
								<th><input type="text" class="form-control" style="width:120px;" id="txtColuna2"/></th>
								<th>
								</th>
							</tr>
						</thead>
						<tbody>
							<?php echo $mostraAtividade; ?>
						</tbody>
					</table>
					
				</div>
			</div>
		</div>
		<button class="btn btn-default" data-toggle="modal" data-target="#loginModal" id="bt1">Nova Atividade</button>	
	</div>
	<!-- Modal -->
		<div class="modal fade" id="loginModal" tabindex="-1" role="dialog" aria-labelledby="Login" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
						<h5 class="modal-title">Edição Atividade</h5>
						<p class='modal-suss'><p>
					</div>

					<div class="modal-body">
						<!-- The form is placed inside the body of modal -->
						<form id="loginForm" method="post" class="form-horizontal" role="form">
							<input type="hidden" name="idAtividade" id="idAtividade" />
							<input type="hidden" name="acao" id="acao"/>
							<div class="form-group">
								<label class="col-xs-3 control-label">Nome</label>
								<div class="col-xs-5">
									<input type="text" class="form-control" name="nome" id="nome" />
								</div>
							</div>

							<div class="form-group">
								<label class="col-xs-3 control-label">Descrição</label>
								<div class="col-xs-5">
									<textarea name="descricao" id="descricao" class="form-control"></textarea>
									
								</div>
							</div>
							
							<div class="form-group">
								<label class="col-xs-3 control-label">DATA INÍCIO</label>
								<div class="col-xs-5">
									<input type="text" class="form-control" name="dtinicio" id="dtinicio" />
								</div>
							</div>
							
							<div class="form-group">
								<label class="col-xs-3 control-label">DATA FIM</label>
								<div class="col-xs-5">
									<input type="text" class="form-control" name="dtfim" id="dtfim" />
								</div>
							</div>
														
							<div class="form-group">
								<label class="col-xs-3 control-label">SITUAÇÃO</label>
								<div class="col-xs-5">
									<select type="text" class="form-control selectpicker" name="situacao" id="situacao">
										<option value="">Selecione uma opção</option>
										<option>Ativo</option>
										<option>Inativo</option>
									</select>
								</div>
							</div>
							
							<div class="form-group">
								<label class="col-xs-3 control-label">STATUS</label>
								<div class="col-xs-5">
									<select class="form-control selectpicker" name="status" id="status">
										<option value="">Selecione uma opção</option>
										<?php echo $sel; ?>
									</select>
								</div>
							</div>

							<div class="form-group">
								<div class="col-xs-5 col-xs-offset-3">
									<button type="submit" class="btn btn-primary" >Salvar</button>
									<button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>									
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
		
<script>
$(function(){
	$("#task-table input").keyup(function(){		

		var index = $(this).parent().index();
		var nth = "#task-table td:nth-child("+(index+1).toString()+")";
		var valor = $(this).val().toUpperCase();
		$("#task-table tbody tr").show();
		$(nth).each(function(){
			if($(this).text().toUpperCase().indexOf(valor) < 0){
				$(this).parent().hide();
			}
		});
	});

	$("#task-table input").blur(function(){
		$(this).val("");
	});	
});

function capturadados(id){
	 var idAt = id;
	 var nome = $('.n'+idAt).text(); 
	 var descr =  $('.d'+idAt).text(); 
	 var dtini =  $('.dti'+idAt).text(); 
	 var dtfi =  $('.dtf'+idAt).text(); 
	 var sit =  $('.si'+idAt).text(); 
	 var sta =  $('.st'+idAt).text(); 
	 $(".modal-suss").text(null);	 
	
	$(function(){	  
		  // Set desired text 
		  //var optionToSet = "Application 1";
		  $("#status option").filter(function(){
			// Get the option by its text
			var hasText = $.trim($(this).text()) ==  sta;
			if(hasText){
			// Set the "selected" value of the <select>.
			$("#status").val($(this).val());
			// Force a refresh.
			$("#status").selectpicker('refresh')
			}
		  });
	});
	$(function(){		  
		  $("#situacao option").filter(function(){
			// Get the option by its text
			var hasText = $.trim($(this).text()) ==  sit;
			if(hasText){
			// Set the "selected" value of the <select>.
			$("#situacao").val($(this).val());
			// Force a refresh.
			$("#situacao").selectpicker('refresh')
			}
		  });


	});
		
	$("#nome").val(nome);
	$("#descricao").val(descr);
	$("#dtinicio").val(dtini);
	$("#dtfim").val(dtfi);
	$("#situacao").val(sit);
	$("#status").val(sta);
	$("#idAtividade").val(idAt);
	$("#acao").val('edit');
}

$(function(){
	$("#dtfim").datepicker({
		dateFormat: 'dd-mm-yy',
		dayNames: ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado'],
		dayNamesMin: ['D','S','T','Q','Q','S','S','D'],
		dayNamesShort: ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb','Dom'],
		monthNames: ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'],
		monthNamesShort: ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'],
		nextText: 'Próximo',
		prevText: 'Anterior'
	});
	$("#dtinicio").datepicker({
		dateFormat: 'dd-mm-yy',
		dayNames: ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado'],
		dayNamesMin: ['D','S','T','Q','Q','S','S','D'],
		dayNamesShort: ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb','Dom'],
		monthNames: ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'],
		monthNamesShort: ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'],
		nextText: 'Próximo',
		prevText: 'Anterior'
	});
    
	
	$("#bt1").click(function(){
		$("#nome").val(null);
		$("#descricao").val(null);
		$("#dtinicio").val(null);
		$("#dtfim").val(null);
		$("#idAtividade").val(null);
		$(".modal-suss").text(null);	 
		$("#acao").val('include');	
		
		$(function(){	  
		  $("#situacao option").filter(function(){
			// Get the option by its text
			var hasText = $.trim($(this).text()) ==  '';
			if(!hasText){
			// Set the "selected" value of the <select>.
			$("#situacao").val($(this).val());
			// Force a refresh.
			$("#situacao").selectpicker('refresh')
			}
		  });
		});
		  $(function(){	
			  $("#status option").filter(function(){
				// Get the option by its text
				var hasText = $.trim($(this).text()) ==  '';
				if(!hasText){
				// Set the "selected" value of the <select>.
				$("#status").val($(this).val());
				// Force a refresh.
				$("#status").selectpicker('refresh')
				}
			  });
		  });
	})
	
	$('#loginForm').validate({
			rules: {
				nome: { required: true, maxlength: 80 },
				descricao: { required: true, maxlength:600 },
				dtinicio: {required: true},
				dtfim: {required: {depends: function(element){return ($('#status').val() == 4);}}},
				status: {required: true},
				situacao: {required: true}
			},
			messages: {
				nome: { required: 'Preencha o campo nome' },
				descricao: { required: 'Preencha o campo descrição'},
				dtinicio: {required: 'Preencha o campo data início'},
				dtfim: {required: 'Preencha o campo data fim'},
				status: {required: 'Selecione um status'},
				situacao: {required: 'Selecione uma situação'}

			},
			submitHandler: function( form ){
				var dados = $( form ).serialize();
				caminho = "http://<?php echo base_url(); ?>atividade/editaSalvar/";
				$.ajax({
					type: "POST",
					url: caminho,
					data: dados,
					success: function( data )
					{
						$(".modal-suss").text(data);
						$("body").load("http://<?php echo base_url(); ?>");
					}
				});

				return false;
			}
		});
	
});

</script>
<script src="http://<?=base_url()?>assets/bootstrap-3.3.7/js/validator.js"></script>	
<script src="http://<?=base_url()?>assets/bootstrap-3.3.7/js/datepicker.js"></script>




<?php $this->load->helper('footer'); ?>