<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->helper('header');
?>
<style>
.row{
    margin-top:40px;
    padding: 0 10px;
}
.clickable{
    cursor: pointer;   
}

.panel-heading div {
	margin-top: -18px;
	font-size: 15px;
}
.panel-heading div span{
	margin-left:5px;
}
.panel-body{
	display: none;
	width:100%;
}
.col-md-6{
	width:100%;
}
.panel-body{
	width:50%;
}
</style>
<div class="container">
	<h1>Lista de Atividades</h1>

		<?php $this->load->helper('menu'); ?>

		<?php 
			foreach($allAtividades as $l){
				$mostraAtividade .= '<tr>
										<td>'.$l->ID.'</td>
										<td>'.$l->NOME.'</td>
										<td style="width:40%;">'.$l->DESCRICAO.'</td>
										<td>'.$l->DATA_INICIO.'</td>
										<td>'.$l->DATA_INICIO.'</td>
										<td>'.$l->DATA_INICIO.'</td>
										<td>
											<button class="btn btn-default" data-toggle="modal" data-target="#loginModal">
											Editar
											</button>
										</td>
									</tr>';
								
			}
	
		?>			
	
    	<div class="row">		
			<div class="col-md-6">
				<div class="panel panel-success">
					<div class="panel-heading">
						<h3 class="panel-title">Atividades</h3>
						<div class="pull-right">
							<span class="clickable filter" data-toggle="tooltip" title="Toggle table filter" data-container="body">
								<i class="glyphicon glyphicon-filter"></i>
							</span>
						</div>
					</div>
					<div class="panel-body">
						<input type="text" class="form-control" id="task-table-filter" data-action="filter" data-filters="#task-table" placeholder="Filtrar Atividades" />
					</div>
					<table class="table table-hover" id="task-table">
						<thead>
							<tr>
								<th>#</th>
								<th>NOME</th>
								<th>DESCRIÇÃO</th>
								<th>DATA ÍNICIO</th>
								<th>DATA ÍNICIO</th>
								<th>DATA ÍNICIO</th>
								<th>
									AÇÃO
								</th>
							</tr>
						</thead>
						<tbody>
							<?php echo $mostraAtividade; ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
			
	</div>
	<!-- Modal -->
		<div class="modal fade" id="loginModal" tabindex="-1" role="dialog" aria-labelledby="Login" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
						<h5 class="modal-title">Login</h5>
					</div>

					<div class="modal-body">
						<!-- The form is placed inside the body of modal -->
						<form id="loginForm" method="post" class="form-horizontal" role="form">
							<div class="form-group">
								<label class="col-xs-3 control-label">Nome</label>
								<div class="col-xs-5">
									<input type="text" class="form-control" name="nome" />
								</div>
							</div>

							<div class="form-group">
								<label class="col-xs-3 control-label">Descrição</label>
								<div class="col-xs-5">
									<input type="text" class="form-control" name="descricao" />
								</div>
							</div>

							<div class="form-group">
								<div class="col-xs-5 col-xs-offset-3">
									<button type="submit" class="btn btn-primary" id="">Login</button>
									<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
<script>
(function(){
    'use strict';
	var $ = jQuery;
	$.fn.extend({
		filterTable: function(){
			return this.each(function(){
				$(this).on('keyup', function(e){
					$('.filterTable_no_results').remove();
					var $this = $(this), 
                        search = $this.val().toLowerCase(), 
                        target = $this.attr('data-filters'), 
                        $target = $(target), 
                        $rows = $target.find('tbody tr');
                        
					if(search == '') {
						$rows.show(); 
					} else {
						$rows.each(function(){
							var $this = $(this);
							$this.text().toLowerCase().indexOf(search) === -1 ? $this.hide() : $this.show();
						})
						if($target.find('tbody tr:visible').size() === 0) {
							var col_count = $target.find('tr').first().find('td').size();
							var no_results = $('<tr class="filterTable_no_results"><td colspan="'+col_count+'">No results found</td></tr>')
							$target.find('tbody').append(no_results);
						}
					}
				});
			});
		}
	});
	$('[data-action="filter"]').filterTable();
})(jQuery);

$(function(){
    // attach table filter plugin to inputs
	$('[data-action="filter"]').filterTable();
	
	$('.container').on('click', '.panel-heading span.filter', function(e){
		var $this = $(this), 
			$panel = $this.parents('.panel');
		
		$panel.find('.panel-body').slideToggle();
		if($this.css('display') != 'none') {
			$panel.find('.panel-body input').focus();
		}
	});
	$('[data-toggle="tooltip"]').tooltip();
	
	/*$('form').submit(function(e){		
           e.preventDefault();
            $.ajax({
                type: "POST", 
                async: false,
                url: "<?php echo site_url("bondform/save_form"); ?>",
                success: function(){alert('Succes');},
                error: function(){alert('Error');}
            });     
        });*/
	
})
$(document).ready(function(){
		$('#loginForm').validate({
			rules: {
				nome: { required: true, minlength: 2 },
				email: { required: true, email: true },
				telefone: { required: true }
			},
			messages: {
				nome: { required: 'Preencha o campo nome', minlength: 'No mínimo 2 letras' },
				email: { required: 'Informe o seu email', email: 'Ops, informe um email válido' },
				telefone: { required: 'Nos diga seu telefone' }

			},
			submitHandler: function( form ){
				var dados = $( form ).serialize();

				$.ajax({
					type: "POST",
					url: "processa.php",
					data: dados,
					success: function( data )
					{
						alert( data );
					}
				});

				return false;
			}
		});
	});
</script>
<script src="http://<?=base_url()?>assets/bootstrap-3.3.7/js/validator.js"></script>	
<?php $this->load->helper('footer'); ?>