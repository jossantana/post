<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Atividades extends CI_model {
	
	function __construct(){
       parent::__construct();
		$this->load->database('default');		
    }

	public function allAtivt() {
		 $this->db->select('A.*,B.NOME as NOMESTATUS,B.ID AS IDSTATUS');
         $this->db->from('tb_atividades A'); 
         $this->db->join('tb_status B', 'B.id=A.status', 'INNER JOIN');
		 $query = $this->db->get();
         return $query->result();
		
	}
	
	function allStatus(){
		$query = $this->db->get('tb_status');
        return $query->result();
	}
	
	public function salvar($data){
		$data['datainicio'] = date('Y-m-d', strtotime($data['datainicio']));
		
		if($data['datafim']){
			$data['datafim'] = date('Y-m-d', strtotime($data['datafim']));
			$this->db->set('data_fim',$data['datafim']);
		}
		
		$this->db->set('nome',strtolower($data['nome']));
		$this->db->set('descricao',$data['descricao']);
		$this->db->set('data_inicio',$data['datainicio']);
		
		$this->db->set('situacao',$data['situacao']);
		$this->db->set('status',$data['status']);
		return $this->db->insert('tb_atividades');
		
	}
	
	
	
	public function atualizar($data){
		
		if($data['datafim']){
			$data['datafim'] = date('Y-m-d', strtotime($data['datafim']));
			$this->db->set('data_fim',$data['datafim']);
		}
		$data['datainicio'] = date('Y-m-d', strtotime($data['datainicio']));
		
		$this->db->where('id', $data['id']);
		$this->db->set('nome',strtolower($data['nome']));
		$this->db->set('descricao',$data['descricao']);
		$this->db->set('data_inicio',$data['datainicio']);
	;
		$this->db->set('situacao',$data['situacao']);
		$this->db->set('status',$data['status']);
		return $this->db->update('tb_atividades');
	}
	
	
}